package com.kpit.org;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.kpit.org.manager.CustomThrow;
import com.kpit.org.manager.SpringSession;
import com.kpit.org.manager.UserDao;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class ZuulLoggingFilter extends ZuulFilter{

	@Autowired
	private UserDao userDao;
	
	private Logger logger=LoggerFactory.getLogger(this.getClass());
	
	@Override
	public Object run() throws ZuulException {
		RequestContext context = RequestContext.getCurrentContext();
		HttpServletRequest request=context.getRequest();
		logger.info("request ->{} rquest uri -> {}",request,request.getRequestURI());
		String xAuthToken=request.getHeader("x-auth-token");
        if (xAuthToken != null && ! xAuthToken.isEmpty()) {
//        	validate session from db and redis code
        	SpringSession session= 	userDao.getSessionBySessionId(xAuthToken);
        	
        	if(this.isValid(session.getExpiryTime())){
        		RequestContext.getCurrentContext().addZuulRequestHeader("x-auth-token", xAuthToken);
        	}else{
//        		CustomThrow.ExceptionMsg("Invalid Session");
        		throw new ZuulException("Invalid session",401,"unAuthorize");
        	}
        }
		return null;
	}

	@Override
	public boolean shouldFilter() {
	     return true;
	}

	@Override
	public int filterOrder() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String filterType() {
		// TODO Auto-generated method stub
		return "pre";
	}
	
	 protected volatile boolean isValid = false;
	    public boolean isValid(Long expiryTime) {
	        if (expiryTime > 0) {
	        	long timeNow = System.currentTimeMillis();
	            if (timeNow >= expiryTime) {
	            	isValid=true;
	            }
	        }
	        return this.isValid;
	    }
}
