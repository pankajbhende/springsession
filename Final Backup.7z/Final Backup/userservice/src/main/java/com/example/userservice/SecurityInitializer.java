
/****************************************************************
*  Header File: SecurityInitializer.java
*  Description: Class for configuring.
*
*
* Copyright (c) OneUltraTech, 2016
****************************************************************/

package com.example.userservice;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityInitializer extends AbstractSecurityWebApplicationInitializer {

}
