package com.example.userservice.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.userservice.User;

@RestController
@RequestMapping(value = "/userlogin")
public class UserController {
	
	@Autowired
	private UserRepository userRepository;

	@PostMapping(value = "/login")
	public @ResponseBody String login(@RequestBody UserLoginCredentials userCredentials, HttpServletRequest request,
			HttpServletResponse httpServletResponse) throws Exception {

 
		User user=userRepository.findUserByUserName(userCredentials.getUserName());
		
		if(user!=null) {
			List<GrantedAuthority> authorities = new ArrayList<>();
			user.getUserRole().stream().forEach(role->{
				authorities.add(new SimpleGrantedAuthority(role.getRole().getRoleName()));
			});
			MyUserDetails	myUserDetails=new MyUserDetails(new UserDto(user.getUserName(),user.getPassword()), authorities);
			SecurityContextHolder.getContext().setAuthentication(
					new UsernamePasswordAuthenticationToken(myUserDetails, null, authorities));

		}

		return request.getSession().getId();

	}

	@GetMapping(value = "/logout")
	public @ResponseBody boolean logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			System.out.println("logout called");
		} catch (Exception e) {
			e.printStackTrace();
		}
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(request, response, auth);
		}

		return true;
	}

	@GetMapping(value = "/test")
	public @ResponseBody String logout() throws Exception {
		try {
			System.out.println("Test Successful");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Test Successful";
	}

}
