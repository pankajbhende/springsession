package com.example.userservice.controller;

import java.io.Serializable;
import java.security.Principal;

public class UserDto implements Principal,Serializable{

	public UserDto(String usernanme,String password){
		this.username=usernanme;
		this.Password=password;
	}
	
	private String username;
	private String Password;
	
	
	public String getPassword() {
		return Password;
	}
 
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		Password = password;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return this.getUsername();
	}

}
