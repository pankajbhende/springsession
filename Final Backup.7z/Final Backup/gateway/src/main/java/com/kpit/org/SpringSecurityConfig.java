package com.kpit.org;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@EnableWebSecurity
@Configuration
//@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableGlobalMethodSecurity(securedEnabled = true, prePostEnabled = true)
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

//
//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
//		/// common
//		http.csrf().disable().authorizeRequests().antMatchers("/userlogin/login").permitAll()
//		.antMatchers("/webjars/**").permitAll().antMatchers("/userlogin/test")
//		.hasAnyRole("ROLE_USER","ROLE_ADMIN").and().authorizeRequests().anyRequest().authenticated();
//        http.addFilterBefore(authenticationTokenFilterBean(), UsernamePasswordAuthenticationFilter.class);
//		http.headers().frameOptions().disable();
//		
////		http.addFilterBefore(new SimpleCORSFilter(),UsernamePasswordAuthenticationFilter.class)
////		.csrf().disable()
////   	.authorizeRequests().antMatchers(
////    			"/userlogin/login").permitAll().
////	//	.authorizeRequests().anyRequest().permitAll();
////   	and().authorizeRequests().anyRequest().authenticated();
//	}
	 
    
//	final TokenAuthenticationFilter tokenFilter = new TokenAuthenticationFilter();
//	@Override
//    protected void configure(HttpSecurity http) throws Exception {
//        http.addFilterBefore(tokenFilter, BasicAuthenticationFilter.class)
//                .csrf()
//                   .disable()
//                .authorizeRequests()
//                .antMatchers("/userlogin/login").permitAll()
//                .antMatchers("userlogin/test")
//                .hasRole("ROLE_USER")
//                .and()
//                .httpBasic();
////                    .realmName(REALM_NAME)
////                    .authenticationEntryPoint(new ApiAuthenticationEntryPoint())
////                    .and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
//    }
//	
//	 @Override
//     protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//         DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
//         daoAuthenticationProvider.setUserDetailsService(appUserDetailsService);
//         auth.authenticationProvider(daoAuthenticationProvider);
//     }
    
	
	 @Autowired
	    private MyUserDetailsService userDetailsService;
	 
 
//	    @Autowired
//	    private RestAuthEntryPoint authenticationEntryPoint;
//
//	    @Autowired
//	    private AuthSuccessHandler authSuccessHandler;
//
//	    @Autowired
//	    private AuthFailureHandler authFailureHandler;


	    @Bean
	    @Override
	    public AuthenticationManager authenticationManagerBean() throws Exception {
	        return super.authenticationManagerBean();
	    }

	    @Bean
	    @Override
	    public UserDetailsService userDetailsServiceBean() throws Exception {
	        return super.userDetailsServiceBean();
	    }

	    @Bean
	    public AuthenticationProvider authenticationProvider() {
	        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
	        authenticationProvider.setUserDetailsService(userDetailsService);
	        authenticationProvider.setPasswordEncoder(new BCryptPasswordEncoder());

	        return authenticationProvider;
	    }

	    @Bean
	    public AuthTokenFilter authenticationTokenFilterBean() throws Exception {
	        AuthTokenFilter authenticationTokenFilter = new AuthTokenFilter();
	        authenticationTokenFilter.setAuthenticationManager(authenticationManagerBean());
	        return authenticationTokenFilter;
	    }

	    @Override
	    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
	        auth.authenticationProvider(authenticationProvider());
	    }

	    @Override
	    protected AuthenticationManager authenticationManager() throws Exception {
	        return super.authenticationManager();
	    }

	 
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable()
                .authorizeRequests()
                .antMatchers("/userlogin/login").permitAll()
				.antMatchers("/userlogin/test").access("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN') or hasRole('ROLE_NON') ")
                .anyRequest().authenticated()
                .and()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authenticationProvider(authenticationProvider());
//                .exceptionHandling()
//                .authenticationEntryPoint(null)
//                .and()
//                .formLogin()
//                .permitAll()
//                .loginProcessingUrl("/login")
//                .usernameParameter("username")
//                .passwordParameter("password")
//                .successHandler(null)
//                .failureHandler(null)
//                .and()
//                .logout()
//                .permitAll()
//                .and()
//                .sessionManagement()
//                .maximumSessions(1);

        http.addFilterBefore(authenticationTokenFilterBean(), UsernamePasswordAuthenticationFilter.class);

        http.authorizeRequests().anyRequest().authenticated();
    }
	
}