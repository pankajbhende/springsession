package com.kpit.org.manager;

public abstract class CustomThrow extends Exception{
	
	private static final long serialVersionUID=1L;
	
	public static void ExceptionMsg(String msg){
		new Exception(msg);
	}
	
}
