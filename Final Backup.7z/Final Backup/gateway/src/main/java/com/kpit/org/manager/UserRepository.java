package com.kpit.org.manager;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<com.kpit.org.entity.User, Long>{

	public com.kpit.org.entity.User findUserByUserName(String userName);
}
