package com.kpit.org;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.kpit.org.manager.MyUserDetails;
import com.kpit.org.manager.SpringSession;
import com.kpit.org.manager.UserDao;
import com.kpit.org.manager.UserDto;
import com.kpit.org.manager.UserRepository;
import com.netflix.zuul.exception.ZuulException;

@Component
@Transactional
public class MyUserDetailsService implements UserDetailsService {

	@Autowired
	private UserDao userDao;

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String accessToken) throws UsernameNotFoundException {
		SpringSession session=new SpringSession();
		try {
			session = userDao.getSessionBySessionId(accessToken);
		} catch (NoResultException e) {
			try {
				throw new ZuulException("Invalid session",401,"unAuthorize");
			} catch (ZuulException e1) {
				e1.printStackTrace();
			}
		}
		
		com.kpit.org.entity.User user = userRepository.findUserByUserName(session.getPrincipalName());
		if (user == null) {
			throw new UsernameNotFoundException(session.getPrincipalName());
		}

		List<GrantedAuthority> authorities = new ArrayList<>();
		user.getUserRole().stream().forEach(role -> {
			authorities.add(new SimpleGrantedAuthority(role.getRole().getRoleName()));
		});

		return new MyUserDetails(new UserDto(user.getUserName(), user.getPassword()), authorities);
	}
}